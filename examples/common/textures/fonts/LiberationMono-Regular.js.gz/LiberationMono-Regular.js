{
  "ix": 0.0234375, 
  "iy": 0.0136364, 
  "row_height": 0.1, 
  "aspect": 0.581818, 
  "ascent": 0.0534483, 
  "descent": 0.019279, 
  "line_gap": 0, 
  "cap_height": 0.0422884, 
  "x_height": 0.0339185, 
  "space_advance": 0.0662177, 

  "chars": { 
  "\u0021": {
    "codepoint": 33,
    "rect": [0, 0.9, 0.0575431, 1],
    "bearing_x": 0.0277478,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0022": {
    "codepoint": 34,
    "rect": [0.0585938, 0.9, 0.14173, 1],
    "bearing_x": 0.0149246,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0023": {
    "codepoint": 35,
    "rect": [0.142578, 0.9, 0.249205, 1],
    "bearing_x": 0.00290948,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0024": {
    "codepoint": 36,
    "rect": [0.25, 0.9, 0.35528, 1],
    "bearing_x": 0.00355603,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0025": {
    "codepoint": 37,
    "rect": [0.355469, 0.9, 0.468615, 1],
    "bearing_x": 0,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0026": {
    "codepoint": 38,
    "rect": [0.46875, 0.9, 0.577155, 1],
    "bearing_x": 0.00231681,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0027": {
    "codepoint": 39,
    "rect": [0.578125, 0.9, 0.637069, 1],
    "bearing_x": 0.0270474,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0028": {
    "codepoint": 40,
    "rect": [0.638672, 0.9, 0.715127, 1],
    "bearing_x": 0.0184267,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0029": {
    "codepoint": 41,
    "rect": [0.716797, 0.9, 0.793252, 1],
    "bearing_x": 0.0181034,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u002a": {
    "codepoint": 42,
    "rect": [0.794922, 0.9, 0.881237, 1],
    "bearing_x": 0.0133621,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u002b": {
    "codepoint": 43,
    "rect": [0.882812, 0.9, 0.983297, 1],
    "bearing_x": 0.00625,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u002c": {
    "codepoint": 44,
    "rect": [0, 0.8, 0.0702586, 0.9],
    "bearing_x": 0.0139547,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u002d": {
    "codepoint": 45,
    "rect": [0.0703125, 0.8, 0.14736, 0.9],
    "bearing_x": 0.0179957,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u002e": {
    "codepoint": 46,
    "rect": [0.148438, 0.8, 0.207974, 0.9],
    "bearing_x": 0.0267241,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u002f": {
    "codepoint": 47,
    "rect": [0.208984, 0.8, 0.309685, 0.9],
    "bearing_x": 0.00614224,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0030": {
    "codepoint": 48,
    "rect": [0.310547, 0.8, 0.41017, 0.9],
    "bearing_x": 0.00668103,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0031": {
    "codepoint": 49,
    "rect": [0.412109, 0.8, 0.511894, 0.9],
    "bearing_x": 0.00797414,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0032": {
    "codepoint": 50,
    "rect": [0.513672, 0.8, 0.611193, 0.9],
    "bearing_x": 0.00775862,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0033": {
    "codepoint": 51,
    "rect": [0.611328, 0.8, 0.71052, 0.9],
    "bearing_x": 0.00689655,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0034": {
    "codepoint": 52,
    "rect": [0.710938, 0.8, 0.812877, 0.9],
    "bearing_x": 0.00554957,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0035": {
    "codepoint": 53,
    "rect": [0.814453, 0.8, 0.913645, 0.9],
    "bearing_x": 0.00689655,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0036": {
    "codepoint": 54,
    "rect": [0, 0.7, 0.097791, 0.8],
    "bearing_x": 0.00813578,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0037": {
    "codepoint": 55,
    "rect": [0.0996094, 0.7, 0.195568, 0.8],
    "bearing_x": 0.00851293,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0038": {
    "codepoint": 56,
    "rect": [0.197266, 0.7, 0.295919, 0.8],
    "bearing_x": 0.00716595,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0039": {
    "codepoint": 57,
    "rect": [0.296875, 0.7, 0.39472, 0.8],
    "bearing_x": 0.00759698,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u003a": {
    "codepoint": 58,
    "rect": [0.396484, 0.7, 0.456021, 0.8],
    "bearing_x": 0.0267241,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u003b": {
    "codepoint": 59,
    "rect": [0.457031, 0.7, 0.52729, 0.8],
    "bearing_x": 0.0189655,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u003c": {
    "codepoint": 60,
    "rect": [0.527344, 0.7, 0.627829, 0.8],
    "bearing_x": 0.00625,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u003d": {
    "codepoint": 61,
    "rect": [0.628906, 0.7, 0.729391, 0.8],
    "bearing_x": 0.00625,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u003e": {
    "codepoint": 62,
    "rect": [0.730469, 0.7, 0.830954, 0.8],
    "bearing_x": 0.00625,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u003f": {
    "codepoint": 63,
    "rect": [0.832031, 0.7, 0.931654, 0.8],
    "bearing_x": 0.00506466,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0040": {
    "codepoint": 64,
    "rect": [0, 0.6, 0.108567, 0.7],
    "bearing_x": 0.00237069,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0041": {
    "codepoint": 65,
    "rect": [0.109375, 0.6, 0.222414, 0.7],
    "bearing_x": 0,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0042": {
    "codepoint": 66,
    "rect": [0.222656, 0.6, 0.322872, 0.7],
    "bearing_x": 0.00872845,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0043": {
    "codepoint": 67,
    "rect": [0.324219, 0.6, 0.426536, 0.7],
    "bearing_x": 0.00608836,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0044": {
    "codepoint": 68,
    "rect": [0.427734, 0.6, 0.526495, 0.7],
    "bearing_x": 0.00872845,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0045": {
    "codepoint": 69,
    "rect": [0.527344, 0.6, 0.625943, 0.7],
    "bearing_x": 0.00872845,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0046": {
    "codepoint": 70,
    "rect": [0.626953, 0.6, 0.721835, 0.7],
    "bearing_x": 0.0104526,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0047": {
    "codepoint": 71,
    "rect": [0.722656, 0.6, 0.822872, 0.7],
    "bearing_x": 0.00608836,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0048": {
    "codepoint": 72,
    "rect": [0.824219, 0.6, 0.919801, 0.7],
    "bearing_x": 0.00872845,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0049": {
    "codepoint": 73,
    "rect": [0, 0.5, 0.0912177, 0.6],
    "bearing_x": 0.0108836,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u004a": {
    "codepoint": 74,
    "rect": [0.0917969, 0.5, 0.182314, 0.6],
    "bearing_x": 0.00948276,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u004b": {
    "codepoint": 75,
    "rect": [0.183594, 0.5, 0.28785, 0.6],
    "bearing_x": 0.00872845,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u004c": {
    "codepoint": 76,
    "rect": [0.289062, 0.5, 0.382435, 0.6],
    "bearing_x": 0.0127694,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u004d": {
    "codepoint": 77,
    "rect": [0.382812, 0.5, 0.48195, 0.6],
    "bearing_x": 0.00695043,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u004e": {
    "codepoint": 78,
    "rect": [0.482422, 0.5, 0.578004, 0.6],
    "bearing_x": 0.00872845,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u004f": {
    "codepoint": 79,
    "rect": [0.578125, 0.5, 0.680172, 0.6],
    "bearing_x": 0.00549569,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0050": {
    "codepoint": 80,
    "rect": [0.681641, 0.5, 0.780078, 0.6],
    "bearing_x": 0.00872845,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0051": {
    "codepoint": 81,
    "rect": [0.78125, 0.5, 0.88389, 0.6],
    "bearing_x": 0.00549569,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0052": {
    "codepoint": 82,
    "rect": [0.884766, 0.5, 0.986328, 0.6],
    "bearing_x": 0.00872845,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0053": {
    "codepoint": 83,
    "rect": [0, 0.4, 0.103394, 0.5],
    "bearing_x": 0.00425647,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0054": {
    "codepoint": 84,
    "rect": [0.103516, 0.4, 0.208365, 0.5],
    "bearing_x": 0.00409483,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0055": {
    "codepoint": 85,
    "rect": [0.208984, 0.4, 0.306668, 0.5],
    "bearing_x": 0.00765086,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0056": {
    "codepoint": 86,
    "rect": [0.308594, 0.4, 0.420555, 0.5],
    "bearing_x": 0.000538793,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0057": {
    "codepoint": 87,
    "rect": [0.421875, 0.4, 0.534914, 0.5],
    "bearing_x": 0,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0058": {
    "codepoint": 88,
    "rect": [0.535156, 0.4, 0.64437, 0.5],
    "bearing_x": 0.00193966,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u0059": {
    "codepoint": 89,
    "rect": [0.644531, 0.4, 0.753691, 0.5],
    "bearing_x": 0.00193966,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u005a": {
    "codepoint": 90,
    "rect": [0.753906, 0.4, 0.859079, 0.5],
    "bearing_x": 0.00393319,
    "advance_x": 0.0662177,
    "flags": 2
  },
  "\u005b": {
    "codepoint": 91,
    "rect": [0.859375, 0.4, 0.935722, 0.5],
    "bearing_x": 0.0220905,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u005c": {
    "codepoint": 92,
    "rect": [0, 0.3, 0.1007, 0.4],
    "bearing_x": 0.00619612,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u005d": {
    "codepoint": 93,
    "rect": [0.101562, 0.3, 0.177909, 0.4],
    "bearing_x": 0.0145474,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u005e": {
    "codepoint": 94,
    "rect": [0.179688, 0.3, 0.278341, 0.4],
    "bearing_x": 0.00716595,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u005f": {
    "codepoint": 95,
    "rect": [0.279297, 0.3, 0.392874, 0.4],
    "bearing_x": -0.000269397,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0060": {
    "codepoint": 96,
    "rect": [0.394531, 0.3, 0.464251, 0.4],
    "bearing_x": 0.0216595,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u0061": {
    "codepoint": 97,
    "rect": [0.464844, 0.3, 0.567322, 0.4],
    "bearing_x": 0.00689655,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0062": {
    "codepoint": 98,
    "rect": [0.568359, 0.3, 0.664318, 0.4],
    "bearing_x": 0.0096444,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0063": {
    "codepoint": 99,
    "rect": [0.666016, 0.3, 0.764076, 0.4],
    "bearing_x": 0.00700431,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0064": {
    "codepoint": 100,
    "rect": [0.765625, 0.3, 0.861584, 0.4],
    "bearing_x": 0.00743535,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0065": {
    "codepoint": 101,
    "rect": [0.863281, 0.3, 0.961934, 0.4],
    "bearing_x": 0.00716595,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0066": {
    "codepoint": 102,
    "rect": [0, 0.2, 0.098653, 0.3],
    "bearing_x": 0.00743535,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0067": {
    "codepoint": 103,
    "rect": [0.0996094, 0.2, 0.195568, 0.3],
    "bearing_x": 0.00770474,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0068": {
    "codepoint": 104,
    "rect": [0.197266, 0.2, 0.290692, 0.3],
    "bearing_x": 0.00996767,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0069": {
    "codepoint": 105,
    "rect": [0.291016, 0.2, 0.3908, 0.3],
    "bearing_x": 0.00770474,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u006a": {
    "codepoint": 106,
    "rect": [0.392578, 0.2, 0.478192, 0.3],
    "bearing_x": 0.00630388,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u006b": {
    "codepoint": 107,
    "rect": [0.478516, 0.2, 0.573289, 0.3],
    "bearing_x": 0.0127155,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u006c": {
    "codepoint": 108,
    "rect": [0.574219, 0.2, 0.666837, 0.3],
    "bearing_x": 0.0143858,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u006d": {
    "codepoint": 109,
    "rect": [0.667969, 0.2, 0.77007, 0.3],
    "bearing_x": 0.00533405,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u006e": {
    "codepoint": 110,
    "rect": [0.771484, 0.2, 0.865234, 0.3],
    "bearing_x": 0.0096444,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u006f": {
    "codepoint": 111,
    "rect": [0.865234, 0.2, 0.964211, 0.3],
    "bearing_x": 0.00700431,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0070": {
    "codepoint": 112,
    "rect": [0, 0.1, 0.0959591, 0.2],
    "bearing_x": 0.0096444,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0071": {
    "codepoint": 113,
    "rect": [0.0976562, 0.1, 0.193669, 0.2],
    "bearing_x": 0.00743535,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0072": {
    "codepoint": 114,
    "rect": [0.195312, 0.1, 0.285453, 0.2],
    "bearing_x": 0.0130388,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0073": {
    "codepoint": 115,
    "rect": [0.287109, 0.1, 0.382099, 0.2],
    "bearing_x": 0.00899784,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0074": {
    "codepoint": 116,
    "rect": [0.382812, 0.1, 0.474246, 0.2],
    "bearing_x": 0.0102371,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0075": {
    "codepoint": 117,
    "rect": [0.474609, 0.1, 0.568359, 0.2],
    "bearing_x": 0.00996767,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0076": {
    "codepoint": 118,
    "rect": [0.568359, 0.1, 0.673963, 0.2],
    "bearing_x": 0.00371767,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0077": {
    "codepoint": 119,
    "rect": [0.675781, 0.1, 0.786611, 0.2],
    "bearing_x": 0.00113147,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0078": {
    "codepoint": 120,
    "rect": [0.787109, 0.1, 0.889965, 0.2],
    "bearing_x": 0.00506466,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u0079": {
    "codepoint": 121,
    "rect": [0.890625, 0.1, 0.996498, 0.2],
    "bearing_x": 0.00355603,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u007a": {
    "codepoint": 122,
    "rect": [0, 0, 0.0964978, 0.1],
    "bearing_x": 0.00792026,
    "advance_x": 0.0662177,
    "flags": 1
  },
  "\u007b": {
    "codepoint": 123,
    "rect": [0.0976562, 0, 0.189467, 0.1],
    "bearing_x": 0.0122306,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u007c": {
    "codepoint": 124,
    "rect": [0.191406, 0, 0.247225, 0.1],
    "bearing_x": 0.0286099,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u007d": {
    "codepoint": 125,
    "rect": [0.248047, 0, 0.339857, 0.1],
    "bearing_x": 0.00899784,
    "advance_x": 0.0662177,
    "flags": 4
  },
  "\u007e": {
    "codepoint": 126,
    "rect": [0.341797, 0, 0.443198, 0.1],
    "bearing_x": 0.00581897,
    "advance_x": 0.0662177,
    "flags": 4
  }
  },
  "kern": {
  }
}
